# INSTALL.md

> **이 파일은 Claude Code가 zip을 풀 때 참고할 설치 절차입니다. 사용자가 직접 읽지 않아도 됩니다.**
>
> 사용자가 "이 zip 풀어서 funnel-check 스킬 설치해줘" 라고 말하면, Claude Code는 이 파일을 읽고 아래 절차를 그대로 실행하면 됩니다.

## 설치 절차

### 1. 압축 해제 위치
- `~/claude-skills/skills/` 가 최종 목적지
- 폴더가 없으면 `mkdir -p ~/claude-skills/skills` 로 생성

### 2. 4개 스킬 폴더를 복사

zip 안의 `skills/` 아래 4개 폴더를 그대로 `~/claude-skills/skills/` 로 복사:

```bash
mkdir -p ~/claude-skills/skills
cp -R skills/funnel-check ~/claude-skills/skills/
cp -R skills/log-explore  ~/claude-skills/skills/
cp -R skills/log-query    ~/claude-skills/skills/
cp -R skills/log-spec     ~/claude-skills/skills/
```

이미 같은 이름의 폴더가 있으면 사용자에게 확인 (덮어쓰기 vs 백업).

### 3. `~/.claude/CLAUDE.md` 의 `## Skills` 섹션에 4줄 등록

`~/.claude/CLAUDE.md` 파일을 열고 `## Skills` 섹션을 찾는다 (없으면 새로 만든다).

다음 4줄을 섹션 아래에 추가 (이미 있으면 중복 추가 안 함):

```markdown
## Skills

- funnel-check: ~/claude-skills/skills/funnel-check/SKILL.md
- log-explore: ~/claude-skills/skills/log-explore/SKILL.md
- log-query: ~/claude-skills/skills/log-query/SKILL.md
- log-spec: ~/claude-skills/skills/log-spec/SKILL.md
```

이 path 등록 덕분에 자연어 호출 ("PDP element 전환률 분석해줘") 시 Claude가 description matching 으로 자동 발동합니다.

### 4. 사용자에게 안내

설치가 끝나면 사용자에게 다음 메시지를 전달:

```
✅ funnel-check 스킬 설치 완료!

설치된 위치:
  ~/claude-skills/skills/funnel-check/
  ~/claude-skills/skills/log-explore/
  ~/claude-skills/skills/log-query/
  ~/claude-skills/skills/log-spec/

CLAUDE.md 등록도 끝났어. 다음 단계:

1. Claude Code 재시작 (⌘⇧P → "Developer: Reload Window")
2. ~/.claude/.mcp.json 에 athena mcp / log-center mcp 가 설정돼 있는지 확인
   (없으면 사내 표준 MCP 설정 가이드 참고)
3. 작업 폴더 만들기:
   mkdir -p ~/data-insight && cd ~/data-insight
4. 자연어로 호출:
   "PDP element 전환률 분석해줘"
   "쇼핑홈 → PDP → 장바구니 전환률 보고 싶어"

자세한 사용법은 README.md 를 참고해.
```

### 5. (선택) 슬래시 커맨드로도 등록하고 싶으면

사용자가 `/funnel-check` 같은 슬래시 호출도 원하면:

```bash
mkdir -p ~/.claude/commands
cp ~/claude-skills/skills/funnel-check/SKILL.md ~/.claude/commands/funnel-check.md
cp ~/claude-skills/skills/log-explore/SKILL.md ~/.claude/commands/log-explore.md
cp ~/claude-skills/skills/log-query/SKILL.md ~/.claude/commands/log-query.md
cp ~/claude-skills/skills/log-spec/SKILL.md ~/.claude/commands/log-spec.md
```

자연어 호출만 쓸 거라면 이 단계는 건너뛰어도 됩니다.

## 주의사항

- **MCP 설정은 자동 설치 안 됨**. 사용자가 사내 표준 MCP 설정을 따로 따라야 합니다 (`~/.claude/.mcp.json`).
- **Athena 권한**도 별도 신청 필요 (`log.analyst_log_table` SELECT).
- 사내망 접근 시 VPN 연결 필요.
- `~/claude-skills/` 경로가 고정이 아닙니다. 사용자가 다른 곳에 풀고 싶으면 CLAUDE.md 의 path 라인을 그에 맞춰 수정해야 합니다.

## 트러블슈팅

| 증상 | 해결 |
|------|------|
| `~/.claude/CLAUDE.md` 파일이 없음 | `mkdir -p ~/.claude && touch ~/.claude/CLAUDE.md` 로 생성 후 `## Skills` 섹션 추가 |
| `## Skills` 섹션이 없음 | 파일 끝에 `## Skills` 헤더 + 4줄 추가 |
| 이미 같은 이름의 스킬 폴더가 있음 | 사용자에게 확인 후 덮어쓰기 또는 `{name}.bak` 으로 백업 후 진행 |
